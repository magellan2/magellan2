package com.javadocking.util;

public class DragProperties
{

}
