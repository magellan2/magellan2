Sanaware Java Docking 1.4.2
(c) Copyright Itsana BVBA 2009.  All rights reserved.

Our website (http://www.javadocking.com).

This product includes:
 - the jar-file of the library: javadocking.jar
 - the jar-file of the examples: samples.jar
 - source files of the library: in directory src
 - source files of the examples: in directory samples
 - the documentation: in docs
 - batch files and shell files for starting the examples:
 		FirstExample.bat		FirstExample.sh
 		DockGallery.bat			DockGallery.sh
 		DynamicExample.bat		DynamicExample.sh
 		WorkspaceExample.bat	WorkspaceExample.sh
 		MainExample.bat			MainExample.sh
 
Before downloading and using the product you have to agree with one of our licenses:
 - buy a commercial license and agree with the commercial license, see http://www.javadocking.com/license/commerciallicense.html.
 - agree with the GPL license, see http://www.javadocking.com/license/GPL.html.
